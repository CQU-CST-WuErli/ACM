﻿# $\qquad \qquad \qquad \qquad\qquad \qquad \qquad \qquad \qquad $最短路
$Time\quad Limit :\quad 1000ms \quad Memory \quad Limit: \quad 32768K$

###$Description$
>$\quad \quad$给定一个$n$个节点，$m$条有向边的图，再给你起点和终点，请问其中有多少条互不重叠的从起点到终点的最短路，即互相没有公共边的最短路个数（可以有公共点），用过边的不能再用。

###$Input$

>输入第一行有一个$T$，表示样例个数。$(T \le 60)$
每个样例第一行有两个整数$n,m$$(n \le 1000, m \le 100000)$
然后是$m$行，代表每一条边的起点终点和权值。
然后是一个两个整数，代表起点和终点。

###$Output$
>输出最短路个数。

###$Sample\quad Input$
>4
4 4
1 2 1
1 3 1
2 4 1
3 4 1
1 4
7 8
1 2 1
1 3 1
2 4 1
3 4 1
4 5 1
4 6 1
5 7 1
6 7 1
1 7
6 7
1 2 1
2 3 1
1 3 3
3 4 1
3 5 1
4 6 1
5 6 1
1 6
2 2
1 2 1
1 2 2
1 2 

###$Sample \quad Output$
>2
2
1
1



