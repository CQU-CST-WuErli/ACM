//
//  Created by  CQU_CST_WuErli
//  Copyright (c) 2016 CQU_CST_WuErli. All rights reserved.
//
//#pragma comment(linker, "/STACK:102400000,102400000")
#include <iostream>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <cctype>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <queue>
#include <stack>
#include <set>
#include <algorithm>
#include <sstream>
#include <ctime>
#define CLR(x) memset(x,0,sizeof(x))
#define OFF(x) memset(x,-1,sizeof(x))
#define MEM(x,a) memset((x),(a),sizeof(x))
#define BUG cout << "I am here" << endl
#define lookln(x) cout << #x << "=" << x << endl
#define SI(a) scanf("%d", &a)
#define SII(a,b) scanf("%d%d", &a, &b)
#define SIII(a,b,c) scanf("%d%d%d", &a, &b, &c)
const int INF_INT=0x3f3f3f3f;
const long long INF_LL=0x7f7f7f7f;
const int MOD=1e9+7;
const double eps=1e-10;
const double pi=acos(-1);
typedef long long  ll;
using namespace std;



int main(int argc, char const *argv[]) {
    freopen("input.txt","w",stdout);
    srand(time(0));
    int t = 60;
    int n, m;
    int maxn = 1000;
    int maxm = 100000;
    cout << t << endl;
    for (int ca = 1; ca <= t; ca++) {
    	if (ca % 5 != 0) {
    		n = rand() % maxn + 1;
    		while (n < 4) n = rand() %  1000 + 1;
    		m = rand() % maxm + 1;
    		while (m < n - 1 || m > (n * (n - 1) / 2)) m = rand() % maxm + 1;
    		cout <<  n << ' ' << m << endl;
    		for (int i = 1; i < n; i++) {
    				int w = rand() % 400 + 1;
    			cout << i << ' ' <<  i + 1 << ' ' << w << endl;
    		}
    		for (int i = 1; i <= m - n + 1; i++) {
    			int u, v, w;
    			u = rand() % n + 1;
    			v = rand() % n + 1;
    			while (u == v) v = rand() % n + 1;
    			w = rand() % 400 + 1;
    			cout << u << ' ' << v <<' ' << w << endl;
    			}
    		int st, ed;
    		st = rand() % n + 1;
    		ed = rand() % n + 1;
    		while (ed == st) ed = rand() % n + 1;
    		cout << st << ' '<< ed << endl;
   		}
   		else {
   			n = rand() % maxn + 1;
    		while (n < 4) n = rand() %  1000 + 1;
    		int ans = rand() % (n - 2) + 1;
    		m = 2 * ans;
    		cout << n << ' ' << m << endl;
    		for (int i = 2 ; i <= ans + 1; i++) {
    			cout << 1 << ' ' << i << ' ' << 1 << endl;
    			cout << i << ' ' << n << ' ' << 1 << endl;
    		}
    		cout << 1 << ' ' << n << endl;
   		}
    }
	return 0;
}
/*
                   _ooOoo_
                  o8888888o
                  88" . "88
                  (| -_- |)
                  O\  =  /O
               ____/`---'\____
             .'  \|     |//  `.
            /  \|||  :  |||//  \
           /  _||||| -:- |||||-  \
           |   | \\  -  /// |   |
           | \_|  ''\---/''  |   |
           \  .-\__  `-`  ___/-. /
         ___`. .'  /--.--\  `. . __
      ."" '<  `.___\_<|>_/___.'  >'"".
     | | :  `- \`.;`\ _ /`;.`/ - ` : | |
     \  \ `-.   \_ __\ /__ _/   .-` /  /
======`-.____`-.___\_____/___.-`____.-'======
                   `=---='
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			佛祖保佑		永无BUG
*/